#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__version__ = '2.5.3'
__author__ = 'Red'
__improver__= 'CFRAW'

def getCredits():

    return '''
     ____  __ __          __          _       _______           __
    / __ \/ //_/___ _____/ /___ ___  (_)___  / ____(_)___  ____/ /__  _____
   / / / / ,< / __ `/ __  / __ `__ \/ / __ \/ /_  / / __ \/ __  / _ \/ ___/
  / /_/ / /| / /_/ / /_/ / / / / / / / / / / __/ / / / / / /_/ /  __/ /
  \____/_/ |_\__,_/\__,_/_/ /_/ /_/_/_/ /_/_/   /_/_/ /_/\__,_/\___/_/
     version %s created by %s & rewrited by %s

    ''' % (__version__, __author__, __improver__,), __version__
